int SetProcedureText( struct {	double dFlag;
								Handle hFn;
								Handle hName;
								double dResult;}* p);

int DoRecreationDialog( struct {Handle hInStr; double dResult;}* p);
